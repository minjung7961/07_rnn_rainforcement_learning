10장 wiki.ko.vec은 별도로 내려받습니다.(약 2GB))</br>
https://fasttext.cc/docs/en/pretrained-vectors.html 에서 Korea의 txt 파일 </br>
</br>

10장 IMDB Dataset.zip 파일은 압축을 풀어 data 폴더에 넣어 실습합니다.</br>
대용량 데이터라 깃허브에 올릴 수 없어 압축합니다.(별도 내려받기 시 공백에 마침표가 추가되는 문제 발생하여 부득이하게 압축 파일로 제공합니다)
